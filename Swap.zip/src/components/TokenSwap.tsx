import React, { useState, useEffect, useCallback } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import * as web3 from "@solana/web3.js";
import { getAssociatedTokenAddress } from "@solana/spl-token";
import { SolanaTracker } from "../SolanaTracker";
import "../App.css";
import {
  FaExchangeAlt,
  FaCog,
  FaChevronDown,
  FaSearch,
  FaTimes,
  FaSun,
  FaMoon,
  FaBars,
} from "react-icons/fa";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import logo from "./logo.gif";
import { predefinedTokens } from "./predefinedTokens";
import { socialLinks, partnerLogos, partnerLogosBottom } from "./partners";
import { Settings, ChevronDown, ArrowDown, CheckCircle, AlertCircle, Loader2, Info } from 'lucide-react'

interface Token {
  symbol: string;
  address: string;
  logo?: string;
  name: string;
  price: number;
  priceChange24h: number;
  balance?: number;
}

const CustomToast = ({ type, message, title }: { type: string, message: string, title?: string }) => {
  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle className="toast-icon text-green-500" />;
      case 'error':
        return <AlertCircle className="toast-icon text-red-500" />;
      case 'loading':
        return <Loader2 className="toast-icon text-[#ba9f32] animate-spin" />;
      default:
        return <Info className="toast-icon text-[#ba9f32]" />;
    }
  };

  return (
    <div className="toast-content">
      {getIcon()}
      <div className="toast-message">
        {title && <div className="toast-title">{title}</div>}
        <div className="toast-description">{message}</div>
      </div>
    </div>
  );
};

const showSuccessToast = (message: string, title?: string) => {
  toast.success(
    <CustomToast type="success" message={message} title={title} />,
    {
      className: 'custom-toast',
      progressClassName: 'custom-toast-progress',
      autoClose: 5000,
    }
  );
};

const showErrorToast = (message: string, title?: string) => {
  toast.error(
    <CustomToast type="error" message={message} title={title} />,
    {
      className: 'custom-toast',
      progressClassName: 'custom-toast-progress',
      autoClose: 5000,
    }
  );
};

const showLoadingToast = (message: string, title?: string) => {
  return toast.loading(
    <CustomToast type="loading" message={message} title={title} />,
    {
      className: 'custom-toast',
      progressClassName: 'custom-toast-progress',
    }
  );
};

export default function Component() {
  const { publicKey, sendTransaction } = useWallet();
  const [fromToken, setFromToken] = useState<Token | null>(null);
  const [toToken, setToToken] = useState<Token | null>(null);
  const [amount, setAmount] = useState("");
  const [toAmount, setToAmount] = useState("");
  const [slippage, setSlippage] = useState("1");
  const [customSlippage, setCustomSlippage] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [showTokenSelector, setShowTokenSelector] = useState<
    "from" | "to" | null
  >(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [tokens, setTokens] = useState<Token[]>(predefinedTokens);
  const [customToken, setCustomToken] = useState<Token | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [hasShownWalletConnectedToast, setHasShownWalletConnectedToast] =
    useState(false);
  const [showComingSoon, setShowComingSoon] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  const fetchTokenData = useCallback(async (tokensToFetch: Token[]) => {
    try {
      const updatedTokens = await Promise.all(
        tokensToFetch.map(async (token) => {
          try {
            const response = await fetch(
              `https://api.dexscreener.com/latest/dex/tokens/${token.address}`,
              {
                method: 'GET',
                headers: {},
              }
            );
            const data = await response.json();

            if (data.pairs && data.pairs.length > 0) {
              const sortedPairs = data.pairs.sort((a: any, b: any) => 
                (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0)
              );
              
              const bestPair = sortedPairs[0];
              
              const priceUsd = bestPair.priceUsd ? parseFloat(bestPair.priceUsd.replace(/[,$]/g, '')) : 0;
              const priceChange24h = bestPair.priceChange?.h24 ? parseFloat(bestPair.priceChange.h24) : 0;

              return {
                ...token,
                price: priceUsd,
                priceChange24h: priceChange24h,
                logo: bestPair.info?.imageUrl || token.logo,
              };
            }
            
            return {
              ...token,
              price: 0,
              priceChange24h: 0,
            };
          } catch (error) {
            console.error(`Error fetching price for ${token.symbol}:`, error);
            return {
              ...token,
              price: 0,
              priceChange24h: 0,
            };
          }
        })
      );

      return updatedTokens;
    } catch (error) {
      console.error("Error fetching token data:", error);
      return tokensToFetch;
    }
  }, []);

  useEffect(() => {
    const updatePrices = async () => {
      if (tokens.length > 0) {
        const updatedTokens = await fetchTokenData(tokens);
        setTokens(updatedTokens);
      }
    };

    updatePrices();
    const interval = setInterval(updatePrices, 30000);

    return () => clearInterval(interval);
  }, [fetchTokenData, tokens.length]);

  const fetchTokenBalance = useCallback(
    async (token: Token, walletPublicKey: web3.PublicKey): Promise<number> => {
      const solana = new web3.Connection(
        "" //ENTER YOUR QUICKNODE RPC URL
      );

      try {
        if (token.symbol === "SOL") {
          const balance = await solana.getBalance(walletPublicKey);
          return balance / web3.LAMPORTS_PER_SOL;
        } else {
          const tokenMintAddress = new web3.PublicKey(token.address);
          const associatedTokenAddress = await getAssociatedTokenAddress(
            tokenMintAddress,
            walletPublicKey
          );

          try {
            const tokenAmount = await solana.getTokenAccountBalance(
              associatedTokenAddress
            );
            return parseFloat(tokenAmount.value.uiAmount?.toString() || "0");
          } catch (tokenError) {
            console.error(
              `Error fetching token balance for ${token.symbol}:`,
              tokenError
            );
            return 0;
          }
        }
      } catch (error) {
        console.error(`Error fetching balance for ${token.symbol}:`, error);
        return 0;
      }
    },
    []
  );

  const fetchBalances = useCallback(
    async (tokensToFetch: Token[]) => {
      if (!publicKey) return tokensToFetch;

      const updatedTokens = await Promise.all(
        tokensToFetch.map(async (token) => {
          const balance = await fetchTokenBalance(token, publicKey);
          return { ...token, balance };
        })
      );

      return updatedTokens;
    },
    [publicKey, fetchTokenBalance]
  );

  const updateTokens = useCallback(
    async (tokensToUpdate: Token[]) => {
      const tokensWithPrices = await fetchTokenData(tokensToUpdate);
      const tokensWithBalances = await fetchBalances(tokensWithPrices);
      setTokens((prevTokens) => {
        const updatedTokens = prevTokens.map((token) => {
          const updatedToken = tokensWithBalances.find(
            (t) => t.address === token.address
          );
          return updatedToken || token;
        });
        return updatedTokens;
      });
      return tokensWithBalances;
    },
    [fetchTokenData, fetchBalances]
  );

  useEffect(() => {
    const initializeTokens = async () => {
      const solToken = tokens.find((t) => t.symbol === "SOL");
      const DogeToken = tokens.find((t) => t.symbol === "DOGE");
      const rayToken = tokens.find((t) => t.symbol === "RAY");
      const usdcToken = tokens.find((t) => t.symbol === "USDC");

      if (solToken && DogeToken && rayToken && usdcToken) {
        const tokensToUpdate = [solToken, DogeToken, rayToken, usdcToken];
        const updatedTokens = await updateTokens(tokensToUpdate);

        if (!fromToken) {
          setFromToken(updatedTokens.find((t) => t.symbol === "SOL") || null);
        }
        if (!toToken) {
          setToToken(updatedTokens.find((t) => t.symbol === "DOGE") || null);
        }
      }
    };

    initializeTokens();
  }, [updateTokens]);

  useEffect(() => {
    if (amount && fromToken && toToken) {
      const fromValue = parseFloat(amount) * fromToken.price;
      const toValue = fromValue / toToken.price;
      setToAmount(toValue.toFixed(6));
    } else if (!amount) {
      setToAmount("");
    }
  }, [amount, fromToken, toToken]);

  const toggleMobileMenu = () => {
    setShowMobileMenu(!showMobileMenu);
  };

  useEffect(() => {
    if (publicKey && !hasShownWalletConnectedToast) {
      showSuccessToast(
        `${publicKey.toString().slice(0, 4)}...${publicKey.toString().slice(-4)}`,
        'Wallet Connected'
      );
      setHasShownWalletConnectedToast(true);
    }
  }, [publicKey, hasShownWalletConnectedToast]);

  const setPercentageAmount = (percentage: number, isFromToken: boolean) => {
    const token = isFromToken ? fromToken : toToken;
    if (token && token.balance !== undefined) {
      if (isFromToken) {
        const calculatedAmount = (token.balance * percentage).toFixed(9);
        setAmount(calculatedAmount);
        if (toToken) {
          const toValue = (parseFloat(calculatedAmount) * token.price) / toToken.price;
          setToAmount(toValue.toFixed(6));
        }
      } else {
        const calculatedToAmount = (token.balance * percentage).toFixed(9);
        setToAmount(calculatedToAmount);
        if (fromToken) {
          const fromValue = (parseFloat(calculatedToAmount) * token.price) / fromToken.price;
          setAmount(fromValue.toFixed(6));
        }
      }
    }
  };

  const handleSwap = async () => {
    if (!publicKey || !fromToken || !toToken) return;

    const loadingToastId = showLoadingToast(
      'Please confirm the transaction in your wallet',
      'Initiating Swap'
    );

    try {
      const solana = new web3.Connection(
        "" //ENTER Quicknode Solana Mainnet RPC LINK HERE
      );
      const solanaTracker = new SolanaTracker(
        solana,
        "" //ENTER Quicknode Solana Mainnet API HERE
      );

      // Get swap instructions
      const swapResponse = await solanaTracker.getSwapInstructions(
        fromToken.address,
        toToken.address,
        parseFloat(amount),
        parseFloat(slippage),
        publicKey.toBase58(),
        0.0005 // Priority fee
      );

      // Decode the swap transaction
      const transactionData = Uint8Array.from(atob(swapResponse.txn), (c) =>
        c.charCodeAt(0)
      );
      const swapTransaction = web3.Transaction.from(transactionData);

      // Create a new transaction to add 0.001 SOL fee to the specified address
      const feeTransaction = new web3.Transaction().add(
        web3.SystemProgram.transfer({
          fromPubkey: publicKey,
          toPubkey: new web3.PublicKey(
            "8TRP8MyyPRdzJeCUYVTZadLgNWivHJiMHmzHPMdxRTnT"
          ),
          lamports: web3.LAMPORTS_PER_SOL * 0.001, // 0.001 SOL in lamports
        })
      );

      // Combine both transactions (swap and fee) into one
      const combinedTransaction = new web3.Transaction();
      combinedTransaction.add(swapTransaction); // Add swap transaction
      combinedTransaction.add(feeTransaction); // Add fee transfer transaction

      // Send the combined transaction
      const signature = await sendTransaction(combinedTransaction, solana);
      toast.dismiss(loadingToastId);
      showSuccessToast(
        `Swapped ${amount} ${fromToken.symbol} for ${toAmount} ${toToken.symbol}`,
        'Swap Successful'
      );
    } catch (error) {
      toast.dismiss(loadingToastId);
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'Failed to complete the swap';
      
      showErrorToast(
        errorMessage,
        'Swap Failed'
      );
    }
  };

  const handleTokenSelection = async (token: Token, isFromToken: boolean) => {
    const updatedTokens = await updateTokens([token]);
    const updatedToken = updatedTokens[0];

    if (isFromToken) {
      setFromToken(updatedToken);
      if (amount && toToken) {
        const newToAmount = (
          (parseFloat(amount) * updatedToken.price) /
          toToken.price
        ).toFixed(6);
        setToAmount(newToAmount);
      }
    } else {
      setToToken(updatedToken);
      if (amount && fromToken) {
        const newToAmount = (
          (parseFloat(amount) * fromToken.price) /
          updatedToken.price
        ).toFixed(6);
        setToAmount(newToAmount);
      }
    }

    setShowTokenSelector(null);
  };

  const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    if (value.length === 44) {
      await fetchCustomToken(value);
    }
  };

  const fetchCustomToken = async (address: string) => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `https://api.dexscreener.com/latest/dex/tokens/${address}`
      );
      const data = await response.json();

      if (data.pairs && data.pairs.length > 0) {
        const pairData = data.pairs[0];
        const newToken: Token = {
          symbol: pairData.baseToken.symbol,
          address: pairData.baseToken.address,
          logo: pairData.info?.imageUrl,
          name: pairData.baseToken.name,
          price: parseFloat(pairData.priceUsd),
          priceChange24h: parseFloat(pairData.priceChange.h24),
        };

        const updatedToken = await updateTokens([newToken]);
        const finalToken = updatedToken[0];

        setCustomToken(finalToken);
        setTokens((prevTokens) => [finalToken, ...prevTokens]);

        if (showTokenSelector === "from") {
          setFromToken(finalToken);
        } else if (showTokenSelector === "to") {
          setToToken(finalToken);
        }

        setSearchTerm("");
      }
    } catch (error) {
      console.error("Error fetching custom token:", error);
      toast.error("Failed to fetch custom token");
    } finally {
      setIsLoading(false);
    }
  };

  const filteredTokens = tokens.filter(
    (token) =>
      token.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      token.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      token.address.toLowerCase() === searchTerm.toLowerCase()
  );

  const formatPrice = (price: number) => {
    if (price === 0) return "0";
    if (price < 0.000001) {
      return price.toFixed(9).replace(/\.?0+$/, "");
    }
    const priceString = price.toString();
    const [integerPart, decimalPart] = priceString.split(".");
    if (!decimalPart) return integerPart;
    const significantPart = decimalPart.match(/[1-9]/);
    if (!significantPart) return integerPart;
    const significantIndex = significantPart.index!;
    return `${integerPart}.${decimalPart.slice(
      0,
      Math.max(significantIndex + 4, 8)
    )}`;
  };

  const TokenSelector: React.FC<{
    token: Token | null;
    onClick: () => void;
  }> = ({ token, onClick }) => (
    <button
      onClick={onClick}
      className="flex items-center space-x-2 bg-black border border-[#ff4400] text-white px-4 py-2 rounded-xl hover:bg-white/10"
    >
      {token ? (
        <>
          {token.logo ? (
            <img src={token.logo} alt={token.symbol} className="w-6 h-6 rounded-full" />
          ) : (
            <div className="w-6 h-6 bg-[#ff4400] rounded-full flex items-center justify-center text-white text-xs font-bold">
              {token.name.charAt(0)}
            </div>
          )}
          <span>{token.symbol}</span>
          <ChevronDown className="w-4 h-4" />
        </>
      ) : (
        <>
          <span>Select</span>
          <ChevronDown className="w-4 h-4" />
        </>
      )}
    </button>
  );

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleSwitchTokens = async () => {
    const newFromToken = toToken;
    const newToToken = fromToken;
    setFromToken(newFromToken);
    setToToken(newToToken);
    setAmount(toAmount);
    setToAmount(amount);

    if (newFromToken && newToToken) {
      const updatedTokens = await updateTokens([newFromToken, newToToken]);
      setFromToken(
        updatedTokens.find((t) => t.address === newFromToken.address) ||
          newFromToken
      );
      setToToken(
        updatedTokens.find((t) => t.address === newToToken.address) ||
          newToToken
      );
    }
  };

  const handleSetCustomSlippage = () => {
    if (customSlippage) {
      const value = parseFloat(customSlippage);
      if (value > 0 && value <= 100) {
        setSlippage(customSlippage);
      } else {
        toast.warning("Slippage must be between 0 and 100");
        setCustomSlippage("");
      }
    }
  };

  const handlePumpFunClick = () => {
    setShowComingSoon(true);
    setTimeout(
      () => setShowComingSoon(false),

      3000
    );
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative">
      {/* Replace the animated background div with video */}
      <video
        className="fixed inset-0 w-full h-full object-cover -z-10"
        autoPlay
        loop
        muted
        playsInline
      >
        <source
          src="https://dogecoin.com/assets/images/Header_Video.mp4"
          type="video/mp4"
        />
      </video>

      {/* Mobile Menu Button - only shows on mobile */}
      <button
        onClick={toggleMobileMenu}
        className="md:hidden fixed top-4 right-4 text-white p-2 z-50"
      >
        <FaBars className="w-6 h-6" />
      </button>

      {/* Desktop Menu - hidden on mobile */}
      <div className="hidden md:flex fixed top-0 left-0 right-0 glass-effect border-b border-[#ff4400]/20 p-4 justify-between items-center z-40">
        <div className="flex items-center space-x-6">
          <a href="/" className="text-white hover:text-[#ff4400] transition-colors">
            Home
          </a>
          <a href="/swap" className="text-white hover:text-[#ff4400] transition-colors">
            Swap
          </a>
          <a href="/stake" className="text-white hover:text-[#ff4400] transition-colors">
            Stake
          </a>
        </div>
        <WalletMultiButton />
      </div>

      {/* Mobile Menu - slides in from right */}
      {showMobileMenu && (
        <div className="md:hidden fixed inset-0 /95 z-40 flex flex-col items-center justify-center">
          <button
            onClick={toggleMobileMenu}
            className="absolute top-4 right-4 text-white p-2"
          >
            <FaTimes className="w-6 h-6" />
          </button>
          <div className="flex flex-col items-center space-y-6">
            <a 
              href="/" 
              className="text-white text-xl hover:text-[#ff4400] transition-colors"
              onClick={toggleMobileMenu}
            >
              Home
            </a>
            <a 
              href="/swap" 
              className="text-white text-xl hover:text-[#ff4400] transition-colors"
              onClick={toggleMobileMenu}
            >
              Swap
            </a>
            <a 
              href="/stake" 
              className="text-white text-xl hover:text-[#ff4400] transition-colors"
              onClick={toggleMobileMenu}
            >
              Stake
            </a>
            <div className="mt-6">
              <WalletMultiButton />
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          {/* <img src={logo} alt="Logo" className="w-24 h-24" /> */}
        </div>
        
        {/* Swap Card */}
        <div className="glass-effect border-2 border-[#ff4400] p-6 rounded-2xl shadow-[0_0_15px_rgba(255,68,0,0.3)]">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-white text-2xl font-bold">Swap Responsibly</h1>
            <button 
              onClick={() => setShowSettings(!showSettings)} 
              className="text-white hover:bg-white/10 p-2 rounded-lg"
            >
              <Settings className="w-6 h-6" />
            </button>
          </div>

          {showSettings && (
            <div className="mb-4 p-4 bg-white/5 rounded-xl border border-[#ba9f32]/20">
              <div className="flex flex-col space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-white font-medium">Slippage Tolerance</span>
                  <div className="flex items-center space-x-2">
                    <div className="slippage-buttons-group">
                      {['0.1', '0.5', '1.0', '3.0'].map((value) => (
                        <button
                          key={value}
                          onClick={() => setSlippage(value)}
                          className={`slippage-preset-button ${slippage === value ? 'active' : ''}`}
                        >
                          {value}%
                        </button>
                      ))}
                    </div>
                    <div className="custom-slippage-input">
                      <input
                        type="number"
                        value={customSlippage}
                        onChange={(e) => setCustomSlippage(e.target.value)}
                        onBlur={handleSetCustomSlippage}
                        placeholder="Custom"
                        className="w-20 bg-transparent text-white text-right outline-none border-b border-[#ba9f32]/30 focus:border-[#ba9f32] transition-colors"
                      />
                      <span className="text-[#ba9f32]">%</span>
                    </div>
                  </div>
                </div>
                {parseFloat(slippage) > 3 && (
                  <div className="text-yellow-500 text-sm">
                    ⚠️ High slippage increases the risk of price impact
                  </div>
                )}
              </div>
            </div>
          )}

          {/* First token input */}
          <div className="bg-white/5 rounded-xl p-4 mb-2">
            <div className="flex justify-between items-center">
              <input
                type="number"
                className="w-full bg-transparent text-white text-3xl font-bold outline-none"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <TokenSelector token={fromToken} onClick={() => setShowTokenSelector("from")} />
            </div>
            <div className="flex justify-between items-center mt-2">
              <div className="text-sm text-gray-400">
                {fromToken && fromToken.balance !== undefined && (
                  <span>Available: {fromToken.balance.toFixed(6)} {fromToken.symbol}</span>
                )}
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setPercentageAmount(0.5, true)}
                  className="percentage-button"
                >
                  50%
                </button>
                <button
                  onClick={() => setPercentageAmount(1, true)}
                  className="percentage-button"
                >
                  MAX
                </button>
              </div>
            </div>
          </div>

          {/* Swap arrow */}
          <div className="flex justify-center -my-2 relative z-10">
            <button 
              onClick={handleSwitchTokens}
              className="bg-black p-2 rounded-lg border-2 border-[#ff4400]"
            >
              <ArrowDown className="w-6 h-6 text-[#ff4400]" />
            </button>
          </div>

          {/* Second token input */}
          <div className="bg-white/5 rounded-xl p-4 mt-2 mb-6">
            <div className="flex justify-between items-center">
              <input
                type="number"
                className="w-full bg-transparent text-white text-3xl font-bold outline-none"
                placeholder="0.00"
                value={toAmount}
                onChange={(e) => {
                  setToAmount(e.target.value);
                  if (fromToken && toToken) {
                    const newFromAmount = ((parseFloat(e.target.value) * toToken.price) / fromToken.price).toFixed(6);
                    setAmount(newFromAmount);
                  }
                }}
              />
              <TokenSelector token={toToken} onClick={() => setShowTokenSelector("to")} />
            </div>
            <div className="flex justify-between items-center mt-2">
              <div className="text-sm text-gray-400">
                {toToken && toToken.balance !== undefined && (
                  <span>Available: {toToken.balance.toFixed(6)} {toToken.symbol}</span>
                )}
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setPercentageAmount(0.5, false)}
                  className="percentage-button"
                >
                  50%
                </button>
                <button
                  onClick={() => setPercentageAmount(1, false)}
                  className="percentage-button"
                >
                  MAX
                </button>
              </div>
            </div>
          </div>

          <button
            onClick={handleSwap}
            disabled={!publicKey || !fromToken || !toToken}
            className="w-full bg-[#ff4400] hover:bg-[#ff4400]/90 text-white py-6 rounded-xl text-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {publicKey ? 'Swap' : 'Connect Wallet'}
          </button>

          <div className="text-center mt-4 text-gray-500">
            Powered by Doge Coin
          </div>
        </div>
      </div>

      {/* Social Links with glass effect */}
      <div className="mt-8 flex flex-col items-center relative z-10">
        <div className="flex space-x-4 mb-4 glass-effect p-4 rounded-xl">
          {socialLinks.map((link) => (
            <a
              key={link.label}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-[#ff4400] transition-colors"
              aria-label={link.label}
            >
              <link.icon className="w-6 h-6" />
            </a>
          ))}
        </div>
        {/* <div className="flex flex-wrap justify-center gap-4">
          {partnerLogos.map((partner) => (
            <a
              key={partner.name}
              href={partner.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block"
            >
              <img
                src={partner.logo}
                alt={partner.name}
                className="h-8 w-auto filter grayscale hover:grayscale-0 transition-all"
              />
            </a>
          ))}
        </div> */}
      </div>

      {showTokenSelector && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="token-selector-modal">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-white">
                Select a token
              </h3>
              <button 
                onClick={() => setShowTokenSelector(null)}
                className="hover:bg-white/10 p-2 rounded-full transition-colors"
              >
                <FaTimes className="w-6 h-6 text-white" />
              </button>
            </div>
            
            <div className="relative mb-6">
              <input
                type="text"
                placeholder="Search by name, symbol or address"
                className="token-search-input"
                value={searchTerm}
                onChange={handleSearch}
              />
              <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>

            <div className="space-y-2 max-h-[400px] overflow-y-auto custom-scrollbar">
              {isLoading ? (
                <div className="text-center text-white py-4">
                  Loading...
                </div>
              ) : (
                filteredTokens.map((token) => (
                  <button
                    key={token.address}
                    className="token-list-item"
                    onClick={() => handleTokenSelection(token, showTokenSelector === "from")}
                  >
                    <div className="flex items-center space-x-3">
                      {token.logo ? (
                        <img src={token.logo} alt={token.symbol} className="w-10 h-10 rounded-full" />
                      ) : (
                        <div className="w-10 h-10 bg-[#ba9f32] rounded-full flex items-center justify-center text-white text-lg font-bold">
                          {token.name.charAt(0)}
                        </div>
                      )}
                      <div className="flex flex-col items-start">
                        <span className="text-lg font-semibold text-white">{token.symbol}</span>
                        <span className="text-sm text-gray-400">{token.name}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-white font-medium">
                        ${token.price > 0 ? formatPrice(token.price) : '0.00'}
                      </span>
                      <div className="flex items-center space-x-1">
                        <span className={`text-sm ${
                          token.priceChange24h >= 0 ? "text-green-500" : "text-red-500"
                        }`}>
                          {token.priceChange24h >= 0 ? "+" : ""}
                          {token.priceChange24h.toFixed(2)}%
                        </span>
                        {token.balance !== undefined && (
                          <span className="text-sm text-gray-400">
                            ({token.balance.toFixed(6)})
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {showSettingsModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="settings-modal">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-white">
                Settings
              </h3>
              <button 
                onClick={() => setShowSettingsModal(false)}
                className="hover:bg-white/10 p-2 rounded-full transition-colors"
              >
                <FaTimes className="w-6 h-6 text-white" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="mb-4">
                <label className="text-white text-lg mb-2 block">Slippage Tolerance</label>
                <div className="slippage-buttons-container">
                  {['0.1', '0.5', '1.0', '3.0'].map((value) => (
                    <button
                      key={value}
                      onClick={() => setSlippage(value)}
                      className={`slippage-button ${slippage === value ? 'active' : ''}`}
                    >
                      {value}%
                    </button>
                  ))}
                  <div className="custom-slippage-input">
                    <input
                      type="number"
                      value={customSlippage}
                      onChange={(e) => setCustomSlippage(e.target.value)}
                      onBlur={handleSetCustomSlippage}
                      placeholder="Custom"
                    />
                    <span>%</span>
                  </div>
                </div>
                {parseFloat(slippage) > 3 && (
                  <div className="text-yellow-500 text-sm mt-2">
                    ⚠️ High slippage increases the risk of price impact
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <ToastContainer
        position="bottom-right"
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
      />
    </div>
  );
}

